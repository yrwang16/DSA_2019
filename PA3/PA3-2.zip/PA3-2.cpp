#include<stdio.h>
#include"avltree1.h"
#include<stdlib.h>

using namespace std;
class node
{
public:
	int a, b;
};
void swap(node &a, node &b)
{
    node c(a);
    a = b;
    b = c;
}
int part(int lo, int hi, node* _elem)
{
    swap(_elem[lo], _elem[lo + rand()%(hi - lo)]);
    int pivot = _elem[lo].b;
    int mi = lo;
    for(int k = lo + 1; k < hi; k++)
    {
        if(_elem[k].b < pivot)
            swap(_elem[++mi], _elem[k]);
    }
    swap(_elem[lo], _elem[mi]);
    return mi;
}
void mysort(int lo, int hi, node* elem)
{
    if(hi - lo < 2)
    {
        return;
    }
    int mi = part(lo, hi, elem);
    mysort(lo, mi, elem);
    mysort(mi + 1, hi, elem);

}
node* bridge = new node[400000];
node* material = new node[500000];

int main()
{
	int n, m;
	scanf("%d %d", &n, &m);
	for(int i = 0; i < n; i++)
	{
		scanf("%d %d", &bridge[i].a, &bridge[i].b);
	}
	for(int i = 0; i < m; i++)
	{
		scanf("%d %d", &material[i].a, &material[i].b);
	}
	mysort(0, n, bridge); mysort(0, m, material);
	AVLTree<int> Material;
	int j = m - 1;
	AVLTreeNode<int>* x;
	long long sum = 0;
	for(int i = n - 1; i  >= 0; i--)
	{
		while((j >= 0) && (material[j].b >= bridge[i].b))
		{
			Material.insert(material[j].a);
			j--;
		}
		x = Material.search(bridge[i].a);
		sum += x->key;
		
		if(x->num > 1) 
			x->num--;
		else
			Material.remove(x->key);
		
	}
	printf("%lld", sum);

	return 0;
}
